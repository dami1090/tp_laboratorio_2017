#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"

int main()
{
    float num1,num2,suma,resta,division,multiplicacion;
    long long int numF;
    char seguir='s';
    int opcion=0;

    while(seguir=='s')
    {
        printf("1- Ingresar 1er operando (A=%.2f)\n",num1);
        printf("2- Ingresar 2do operando (B=%.2f)\n",num2);
        printf("3- Calcular la suma (A+B)\n");
        printf("4- Calcular la resta (A-B)\n");
        printf("5- Calcular la division (A/B)\n");
        printf("6- Calcular la multiplicacion (A*B)\n");
        printf("7- Calcular el factorial (A!)\n");
        printf("8- Calcular todas las operaciones\n");
        printf("9- Salir\n");

        scanf("%d",&opcion);

        switch(opcion)
        {
            case 1:
                printf("\n");
               num1 = pedirNumero();
               system("cls");
                printf("\t\t El numero es A= %.2f\n", num1);
                printf("\n");
                system("pause");
                break;
            case 2:
                printf("\n");
               num2 = pedirNumero();
               system("cls");
               printf("\t\t El numero es B=%.2f\n",num2);
               printf("\n");
               system("pause");
                break;
            case 3:
                printf("\n");
                suma = sumar(num1,num2);
                system("cls");
                system("color 06");
                printf("\t\t La suma es: %.2f\n",suma);
                printf("\n");
                system("pause");
                break;
            case 4:
                printf("\n");
                resta =restar(num1,num2);
                system("cls");
                system("color 02");
                printf("\t\t La resta es: %.2f\n",resta);
                system("pause");
                printf("\n");
                break;
            case 5:
                printf("\n");

                while(num2==0||num2<0)
                {
                    num2=validar();
                }
                division= dividir(num1,num2);
                system("cls");
                system("color 03");
                printf("\t\t La division es: %.2f\n",division);
                printf("\n");
                system("pause");
                break;
            case 6:
                printf("\n");
                multiplicacion= multiplicar(num1,num2);
                system("cls");
                system("color 04");
                printf("\t\t La multiplicacion es: %.2f\n",multiplicacion);
                printf("\n");
                system("pause");
                break;
            case 7:
                printf("\n");
                numF=factorial(num1);
                system("cls");
                system("color 05");
                printf("\t\t El factorial del primer numero es: %lli \n",numF);
                printf("\n");
                system("pause");
                break;
            case 8:
                system("cls");
                printf("\n");
                system("color 09");
                suma = sumar(num1,num2);
                printf("\t\t La suma es: %.2f\n",suma);
                resta =restar(num1,num2);
                printf("\t\t La resta es: %.2f\n",resta);
                division= dividir(num1,num2);
                printf("\t\t La division es: %.2f\n",division);
                multiplicacion= multiplicar(num1,num2);
                printf("\t\t La multiplicacion es: %.2f\n",multiplicacion);
                numF=factorial(num1);
                printf("\t\t El factorial del primer numero es: %lli \n",numF);
                printf("\n");
                system("pause");

                break;
            case 9:
                seguir = 'n';
                break;
        }

}
    return 0;



}







