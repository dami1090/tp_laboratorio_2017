#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"

float pedirNumero()
{
    float numero;
    printf("Ingrese un numero: ");
    scanf("%f", &numero);

    return numero;
}
float sumar(float n1, float n2)
{
    float resultado;
    resultado = n1 + n2;

    return resultado;
}
float restar(float n1, float n2)
{
    float resultado;
    resultado=n1-n2;
    return resultado;
}
float dividir(float n1, float n2)
{

    float resultado;
    resultado=n1/n2;
    return resultado;
}
float multiplicar(float n1, float n2)
{
    float resultado;
    resultado=n1*n2;
    return resultado;
}
long long int factorial(long long int n1)
{
    while(n1==0 || n1==1)
    {
        return 1;
    }
    while(n1<0)
    {
        printf("\t Error,ingrese numero natural: \n");
        n1 = pedirNumero();

    }
    long long int i;
    long long int fact=1;
    for(i=n1;i>0;i--)
     {
         fact=fact*i;
     }
     return fact;
}
float validar()
{
    float numero;

        printf("\t Error, no se puede dividir por 0 o menor\n");
        numero = pedirNumero();

    return numero;
}
