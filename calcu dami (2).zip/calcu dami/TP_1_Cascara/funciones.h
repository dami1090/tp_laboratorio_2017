#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
/** \brief pide un numero y lo guarda
 *
 * \param el numero a ingresar
 * \return devuelve un numero
 *
 */
float pedirNumero();
/** \brief suma 2 numeros
 *
 * \param numero A
 * \param numero B
 * \return devuelve los numeros sumados
 *
 */
float sumar(float num1, float num2);
/** \brief resta 2 numeros
 *
 * \param numero A
 * \param numero B
 * \return devuelve los numeros restados
 *
 */
float restar(float num1, float num2);
/** \brief divide los numeros
 *
 * \param numero A
 * \param numero B
 * \return devuelve el cociente
 *
 */
float dividir(float n1, float n2);
/** \brief multiplica
 *
 * \param numero A
 * \param numero B
 * \return devuelve el producto
 *
 */

float multiplicar(float n1, float n2);
/** \brief factorial N!
 *
 * \param numero A
 * \return devuelve el factorial del numero A
 *
 */
long long int factorial(long long int n1);
/** \brief valida un numero
 *
 * \param numero a validar
 * \return pide reingresarun numero valido
 *
 */
float validar();
#endif // FUNCIONES_H_INCLUDED
